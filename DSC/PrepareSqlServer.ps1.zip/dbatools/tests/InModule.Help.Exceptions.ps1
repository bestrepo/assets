$global:FunctionHelpTestExceptions = @(
    "TabExpansion2"
)
