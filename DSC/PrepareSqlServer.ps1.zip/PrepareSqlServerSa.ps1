#
# Copyright="� Microsoft Corporation. All rights reserved."
#
configuration PrepareSqlServerSa
{
    param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLAdminAuthCreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLAuthCreds,

        [Parameter(Mandatory)]
        [UInt32]$DisksCount,

        [Parameter(Mandatory)]
        [String]$DiskSizeInGB,

        [Parameter(Mandatory)]
        [UInt32]$DatabaseEnginePort,

        [Parameter(Mandatory)]
        [String]$WorkloadType,

        [Parameter(Mandatory)]
        [String]$ConnectionType,

        [Parameter(Mandatory)]
        [UInt32]$numberOfTempDBfiles,

        [Parameter(Mandatory)]
        [UInt32]$sizeOfEachTempDBfileInMB,

        [Parameter(Mandatory)]
        [string]$tempDBautogrowthPattern,

        [Parameter(Mandatory)]
        [UInt32]$tempDBlogSizeInMB,

        [Parameter(Mandatory)]
        [string]$tempDBlogAutogrowthPattern

    )

    Import-DscResource -ModuleName xComputerManagement,CDisk,xActiveDirectory,XDisk,xSql, xSQLServer, xSQLps,xNetworking, xPSDesiredStateConfiguration, xDatabase, dbatools
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential($SQLAdminAuthCreds.UserName, $SQLAdminAuthCreds.Password)

    . "$PSScriptRoot\Common.ps1"

    Node localhost
    {

        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
            AllowModuleOverwrite = $true
        }

        $setFirewallRules = Set-SqlFirewallRule -ConnectionType $ConnectionType

        if($setFirewallRules -eq $true)
        {
            xFirewall DatabaseEngineFirewallRule
            {
                Direction = "Inbound"
                Name = "SQL-Server-Database-Engine-TCP-In"
                DisplayName = "SQL Server Database Engine (TCP-In)"
                Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
                DisplayGroup = "SQL Server"
                State = "Enabled"
                Access = "Allow"
                Protocol = "TCP"
                LocalPort = $DatabaseEnginePort -as [String]
                Ensure = "Present"
            }
        }

        xSqlTsqlEndpoint AddSqlServerEndpoint
        {
            InstanceName = "MSSQLSERVER"
            PortNumber = $DatabaseEnginePort
            SqlAdministratorCredential = $SQLAdminAuthCreds
        }

        xSQLServerStorageSettings AddSQLServerStorageSettings
        {
            InstanceName = "MSSQLSERVER"
            OptimizationType = $WorkloadType
            DependsOn = "[xSqlTsqlEndpoint]AddSqlServerEndpoint"
        }
        
        xSqlLogin AddSQLAUTH
        {
            Name = $SQLAuthCreds.UserName
            Password = $SQLAuthCreds
            LoginType = "SqlLogin"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $SQLAdminAuthCreds
            DependsOn = "[xSQLServerStorageSettings]AddSQLServerStorageSettings"
        }

        Script ConfigureDataStoragePool 
        { 
		    SetScript = { 
			$disks = Get-PhysicalDisk -CanPool $true | Sort-Object deviceid | select -first ((Get-PhysicalDisk -CanPool $true | Sort-Object deviceid).count/2)
			New-StoragePool -FriendlyName "DataPool" -StorageSubsystemFriendlyName "Windows Storage*" -PhysicalDisks $disks | New-VirtualDisk -FriendlyName "DataDisk" -UseMaximumSize -NumberOfColumns $disks.Count -ResiliencySettingName "Simple" -ProvisioningType Fixed | Initialize-Disk -Confirm:$False -PassThru | New-Partition -DriveLetter S �UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel "SQLDATA" -AllocationUnitSize 65536 -Confirm:$false			
		} 

		    TestScript = { 
			Test-Path S:\ 
		} 
		    GetScript = { <# This must return a hash table #> }
            DependsOn = "[xSqlLogin]AddSQLAUTH"
        }

        Script ConfigureLogsStoragePool 
        { 
		    SetScript = { 
			$disks = Get-PhysicalDisk -CanPool $true
			New-StoragePool -FriendlyName "LogsPool" -StorageSubsystemFriendlyName "Windows Storage*" -PhysicalDisks $disks | New-VirtualDisk -FriendlyName "LogsDisk" -UseMaximumSize -NumberOfColumns $disks.Count -ResiliencySettingName "Simple" -ProvisioningType Fixed | Initialize-Disk -Confirm:$False -PassThru | New-Partition -DriveLetter L �UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel "SQLLOGS" -AllocationUnitSize 65536 -Confirm:$false			
		} 

		    TestScript = { 
			Test-Path L:\ 
		} 
		    GetScript = { <# This must return a hash table #> }
            DependsOn = "[Script]ConfigureDataStoragePool"
        }   

        xSQLServerSettings UpdateSqlServerSettings
        {
            InstanceName = "MSSQLSERVER"
            SqlAdministratorCredential = $SQLAdminAuthCreds
            SqlAuthEnabled = "Disabled"
            FilePath = "S:\DATA"
            LogPath = "L:\LOG"
            DependsOn = "[Script]ConfigureLogsStoragePool"
        }

        Script ConfigureTempDB 
        { 
		    SetScript = { 
                Set-SqlTempDbConfiguration -SqlServer localhost -DataFileCount $using:numberOfTempDBfiles -DataFileSizeMB (($using:sizeOfEachTempDBfileInMB)*($using:numberOfTempDBfiles)) -TempDBfileAutoGrowthPattern $using:tempDBautogrowthPattern -LogFileSizeMB $using:tempDBlogSizeInMB -TempDBlogAutoGrowthPattern $using:tempDBlogAutogrowthPattern -DataPath D:\ -LogPath D:\
                Restart-Computer
        } 

		    TestScript = { 
			Test-Path D:\tempdb.mdf
		} 
		    GetScript = { <# This must return a hash table #> }
            DependsOn = "[xSQLServerSettings]UpdateSqlServerSettings"
        }   
    }
}