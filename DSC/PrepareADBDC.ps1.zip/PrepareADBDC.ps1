﻿configuration PrepareADBDC
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DNSServer

    )

    Import-DscResource -ModuleName  xStorage, xNetworking
    $DriveLetters = 'CDFGHIJKLMNOPQRSTUVWXYZ'


    Node localhost
    {

        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyAndAutoCorrect'
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
            AllowModuleOverwrite = $true
        }

        Get-Disk | Where-Object {$_.NumberOfPartitions -lt 1} | Foreach-Object {
        Write-Verbose "disk($($_.Number))" -Verbose
        xDisk "disk($($_.Number))"
        {
            DriveLetter = $DriveLetters[$_.Number]
            DiskNumber = $_.Number
            FSFormat = 'NTFS'        
        }
        }

        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }

        script NetAdapterName
        {
            GetScript = {
                Import-module xNetworking
                $getResult = Get-xNetworkAdapterName -Name 'Ethernet1'
                return @{
                    result = $getResult
                }
            }
            TestScript = {
                Import-module xNetworking
                Test-xNetworkAdapterName -Name 'Ethernet1'
            }
            SetScript = {
                Import-module xNetworking
                Set-xNetworkAdapterName -Name 'Ethernet1' -IgnoreMultipleMatchingAdapters
            }

        }
        xDnsServerAddress DnsServerAddress
        {
            Address        = $DNSServer
            InterfaceAlias = 'Ethernet1'
            AddressFamily  = 'IPv4'
            DependsOn="[WindowsFeature]ADDSInstall"
        }
   }
}
