# Blank Template

This is an empty template and parameters file with the schema reference and top-level properties defined.
