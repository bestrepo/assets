﻿configuration InitializeDataDisks
{


    Import-DscResource -ModuleName xStorage
    $DriveLetters = 'CDFGHIJKLMNOPQRSTUVWXYZ'


    Node localhost
    {

        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
            AllowModuleOverwrite = $true
        }

        Get-Disk | Where-Object {$_.NumberOfPartitions -lt 1} | Foreach-Object {
        Write-Verbose "disk($($_.Number))" -Verbose
        xDisk "disk($($_.Number))"
        {
            DriveLetter = $DriveLetters[$_.Number]
            DiskNumber = $_.Number
            FSFormat = 'NTFS'        
        }
        }
   }
}